add_x <- function(x){
  function(y) {x+y}
}
